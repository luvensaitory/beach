﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Device.Location;
using System.Xml;

namespace Wwllcome_to_beach
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //class CLocation
        //{
        //    GeoCoordinateWatcher watcher;

        //    public void GetLocationEvent()
        //    {               
        //        this.watcher = new GeoCoordinateWatcher();
        //        this.watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
        //        bool started = this.watcher.TryStart(false, TimeSpan.FromMilliseconds(2000));
        //        if (!started)
        //        {
        //            Console.WriteLine("GeoCoordinateWatcher timed out on start.");
        //        }
        //    }

        //    void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        //    {
        //        //PrintPosition(e.Position.Location.Latitude, e.Position.Location.Longitude);
        //         "Lat: " + e.Position.Location.Latitude.ToString() + ", Long: " + e.Position.Location.Longitude.ToString();
                
        //    }
        //    /*
        //    void PrintPosition(double Latitude, double Longitude)
        //    {
        //        //Console.WriteLine("Latitude: {0}, Longitude {1}", Latitude, Longitude);
        //        label3.Text = "Lat: " + Latitude.ToString() + ", Long: " + Longitude.ToString();
        //    }*/
        //}

        double[] Gpsx = new double[]{25.2840888,
25.1694505,
25.1555257,
25.166789,
25.0447585,
24.8706865,
24.7733709,
24.3808063,
24.3839356,
24.3108692,
23.6959851,
25.0457295,
25.2463029,
22.9581555,
25.2374681,
25.2374681,
25.2081187,
25.135401,
24.9955778,
24.9244728,
24.8264795,
24.723339,
24.3755475,
24.3755475,
23.6791452,
23.1494484,
22.61212,
22.8323329,
22.5166103,
24.5830364,
24.5830364,
24.9899414,
24.9972021,
24.9972021,
25.2133397,
25.1883804,
};
        double[] Gpsy = new double[]{121.5150143,
121.4393644,
121.4541103,
121.4080405,
121.0770667,
120.9467515,
120.89263,
120.5846525,
120.5844863,
120.5498753,
121.5188424,
121.9237228,
121.469579,
120.168874,
121.682913,
121.682913,
121.4240791,
121.3647681,
121.0920566,
121.0545772,
120.8305759,
120.8498559,
120.6134211,
120.6134211,
120.1555317,
120.0615604,
120.1670289,
120.9892319,
120.3274183,
121.8901163,
121.8901163,
121.8633351,
121.9388703,
121.9388703,
121.5759788,
121.6703119};
        string[] gpsn = new string[]{"新竹海水浴場",
"崎頂海水浴場",
"通霄海水浴場",
"高美海水浴場",
"三條崙海水浴場親水公園",
"馬沙溝海水浴場",
"旗津海水浴場",
"杉原海水浴場",
"大鵬灣海水浴場",
"內埤海水浴場",
"豆腐岬海水浴場",
"外澳海水浴場",
"鹽寮海水浴場",
"金沙灣海濱公園",
"金山海濱浴場",
"萬里海水浴場"};
        Color cc;
        double xx, yy;//緯度經度
        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.beach1;
            label1.Left = (this.ClientSize.Width - label1.Size.Width) / 2;
            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label4.BackColor = System.Drawing.Color.Transparent;
            label2.Left = (this.ClientSize.Width - label1.Size.Width) / 2;
            cc = button1.BackColor;
            timer1.Enabled = true;
            //pictureBox1.Visible = false;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar) { 
                case (char)Keys .Escape:
                    //this.Close();
                    this.WindowState = FormWindowState.Normal;
                    break;

            
            }
        }
        GeoCoordinateWatcher watcher = new GeoCoordinateWatcher();
        int j=0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Do not suppress prompt, and wait 1000 milliseconds to start.
            
            watcher.TryStart(false, TimeSpan.FromMilliseconds(1000));
            GeoCoordinate coord = watcher.Position.Location;
            int i = 0;
            if (coord.IsUnknown != true)
            {
                //{watcher.TryStart(false, TimeSpan.FromMilliseconds(5000));}
                xx = coord.Latitude; yy = coord.Longitude;
                for (i = 0; i < Gpsx.Length; i++)
                {
                    if ((Math.Abs(coord.Latitude - Gpsx[i]) < 0.0001) && (Math.Abs(coord.Longitude - Gpsy[i]) < 0.0001))//緯度&&經度
                    {
                        label2.Text = "你好像已經在 " + gpsn[i] + "了";
                        break;
                    }
                }
            }
            else {
                //label2.Text = "gps讀取中.";
                j++;
                if (j < 4)
                {
                    label2.Text += ".";
                }
                else
                {
                    label2.Text = "gps讀取中";
                    j = 0;
                }
            }
                        
            if (i == Gpsx.Length)
            {
                label2.Text = "妳好像不在海邊"+Environment.NewLine+ "要出發了嗎!";
            }
            label3.Text="Lat: "+coord.Latitude.ToString()+", Long: "+coord.Longitude.ToString();
        }
        
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

            timer1.Enabled = false;
            panel1.Location = new Point(0, 0);
            panel1.Size = this.Size;
            panel1.Visible = true;
            panel1.BackgroundImage = Properties.Resources.beach2;
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            timer2.Enabled = true;

            button4.Size = button1.Size;
            button5.Size = button1.Size;
            button5.Location = new Point(200, this.Size.Height - 150);//下一頁;
            //button4.Location = new Point(20,0);//下一頁;
            button4.Location = new Point(this.Size.Width - 500, this.Size.Height - 150);
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            }
            else
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
        }
        int k=0;
        private void timer2_Tick(object sender, EventArgs e)
        {
            string ss="想在海灘玩什麼呢?";
            label4.Text+= ss[k++];
            if (k == ss.Length)
                timer2.Enabled = false;
        }
        bool[] play = new bool[] { false, false, false };
        private void button1_Click(object sender, EventArgs e)
        {
            play[0] = !play[0];
            if (play[0])
            {
                button1.BackColor = Color.YellowGreen;
            }
            else
                button1.BackColor = cc;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            play[1] = !play[1];
            if (play[1])
            {
                button2.BackColor = Color.YellowGreen;
            }
            else
                button2.BackColor = cc;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            play[2] = !play[2];
            if (play[2])
            {
                button3.BackColor = Color.YellowGreen;
            }
            else
                button3.BackColor = cc;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Size = this.Size;
            panel2.Visible = true;
            panel2.Location = new Point(0, 0);            
            panel2.BackgroundImage = Properties.Resources.beach3;
            panel2.BackgroundImageLayout = ImageLayout.Stretch;

            XmlDocument xd = new XmlDocument();
            
            
                xd.Load("http://opendata.epa.gov.tw/webapi/api/rest/datastore/355000000I-000004/?format=xml&token=yourToken");
            
            //catch { MessageBox.Show("下載失敗");}
            List<string> city =new List<string>();
            List<int> UVI = new List<int>();
            List<double> WGS84Lon = new List<double>();
            List<double>WGS84Lat = new List<double>();
            List<string> PublishTime = new List<string>();
            //http://opendata.epa.gov.tw/webapi/api/rest/datastore/355000000I-000004/?format=csv&token=yourToken
            //for (int i = 0; i <= xd.SelectSingleNode("Data").ChildNodes.Count - 1; i++)
            int ans=-1;//查 什麼縣市
            double mx = 100000000000;
            for (int ii = 0; ii <= xd.SelectSingleNode("UV").ChildNodes.Count - 1; ii++)
            {
                city.Add(xd.SelectNodes("//SiteName")[ii].InnerText);
                UVI.Add( Convert .ToInt32(   xd.SelectNodes("//UVI")[ii].InnerText));
                string x = xd.SelectNodes("//WGS84Lat")[ii].InnerText;//緯度
                string y = xd.SelectNodes("//WGS84Lon")[ii].InnerText;

                WGS84Lon.Add(Convert.ToDouble(y[0].ToString() + y[1].ToString() + y[2].ToString()) + Convert.ToDouble(y[4].ToString() + y[5].ToString()) / 60 + Convert.ToDouble(y[7].ToString() + y[8].ToString()) / 3600);
                WGS84Lat.Add(Convert.ToDouble(x[0].ToString() + x[1].ToString()) + Convert.ToDouble(x[3].ToString() + x[4].ToString()) / 60 + Convert.ToDouble(x[6].ToString() + x[7].ToString()) / 3600);
                double temp =Math.Abs(xx - WGS84Lat[ii])*Math.Abs(xx - WGS84Lat[ii])  +   Math.Abs(yy-WGS84Lon[ii])*Math.Abs(yy-WGS84Lon[ii]);
                if (temp < mx)
                {
                    mx = temp;
                    ans = ii;
                }
                
                PublishTime.Add(xd.SelectNodes("//PublishTime")[ii].InnerText);
                //MessageBox.Show(city[ii] + Environment.NewLine + UVI[ii].ToString() + Environment.NewLine +
                //    "經度:" + WGS84Lon[ii].ToString() + "  緯度:" + WGS84Lat[ii].ToString() + Environment.NewLine + PublishTime[ii]);
            }
            label5.Text = "建議您去" + city[ans] + " 的海灘 目前UVI值為 " + UVI[ans];
               
        }

        System.DateTime currentTime = new System.DateTime();  
        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            j = 0; k = 0;
            label4.Text = "你";

        }
    }
}
